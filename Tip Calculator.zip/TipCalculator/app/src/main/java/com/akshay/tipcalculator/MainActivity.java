/*
    Assignment      : Homework 01
    File Name       : MainActivity.java
    FullNames       : Akshay Karai, Naga Poorna Pujitha Perakalapudi
    Group           : 34
 */
package com.akshay.tipcalculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView textViewTipResult;
    TextView textViewTotalResult;
    EditText editTextValue;
    double tipValue = 10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.mipmap.ic_launcher);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        setContentView(R.layout.activity_main);

        editTextValue = (EditText) findViewById(R.id.Value);
        textViewTipResult = (TextView) findViewById(R.id.tipResult);
        textViewTotalResult = (TextView) findViewById(R.id.totalResult);
        RadioGroup radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        final SeekBar seekbar = (SeekBar) findViewById(R.id.seekBar);
        seekbar.setMax(50);
        seekbar.setProgress(25);
        seekbar.setEnabled(false);
        final TextView seekBarValue = (TextView) findViewById(R.id.seekbarValue);
        seekBarValue.setText("25%");
        Button exit = (Button) findViewById(R.id.exitButton);

        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        editTextValue.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if(tipValue != 0){
                    updateResult(tipValue);
                }
            }
        });

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                String billTotalStr = editTextValue.getText().toString();

                if (billTotalStr == null || billTotalStr.isEmpty()) {
                    editTextValue.setError("Enter Bill Total");
                } else {
                    int checkedRadioButton = radioGroup.getCheckedRadioButtonId();
                    String radioTag = ((RadioButton) findViewById(checkedRadioButton)).getTag().toString();

                    if (radioTag.equals("Custom")) {
                        updateResult(seekbar.getProgress());
                        seekbar.setEnabled(true);
                    } else {
                        seekbar.setEnabled(false);
                        double tipPercent = Double.parseDouble(radioTag);
                        tipValue = tipPercent;
                        updateResult(tipPercent);

                    }
                }

            }
        });

        seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                tipValue = i;
                String billTotalStr = editTextValue.getText().toString();
                Double billTotal = Double.parseDouble(billTotalStr);
                updateResult(i);
                seekBarValue.setText(i + "%");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    private void updateResult(double tip){
        String billTotalValue = editTextValue.getText().toString();
        Double billTotal = Double.parseDouble(billTotalValue);
        Double tipTotal = (billTotal * tip) / 100;
        Double finalAmount = billTotal + tipTotal;
        textViewTipResult.setText(tipTotal.toString());
        textViewTotalResult.setText(finalAmount.toString());
    }

}


